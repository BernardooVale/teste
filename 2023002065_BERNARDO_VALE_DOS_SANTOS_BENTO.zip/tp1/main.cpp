

#include <iostream>

#include "Grafo.h"
#include "Vertice.h"

using namespace std;

int main(){

    int numCidades, numCaminhos, numConjuntos, cidadesCriadas = 0;
    string nome, origem, destino;
    Grafo grafo;

    cin >> numCidades >> numCaminhos;

    for (int i = 0; i < numCaminhos; i++) {
        cin >> origem >> destino;

        if (grafo.achaCidadeString(origem) == nullptr) {
            Vertice aux(cidadesCriadas, origem, numCidades);
            grafo.adCidade(aux);
            cidadesCriadas++;
        }

        if (grafo.achaCidadeString(destino) == nullptr) {
            Vertice aux(cidadesCriadas, destino, numCidades);
            grafo.adCidade(aux);
            cidadesCriadas++;
        }

        grafo.achaCidadeString(origem)->adCaminho(grafo.achaCidadeString(destino)->pegaID());
    }

    grafo.defCapital();
    cout << grafo.achaCidadeID(grafo.pegaCapital())->pegaNome() << endl;
    numConjuntos = grafo.Kosaraju();
    grafo.patrulhamento(numConjuntos);

    return 0;
}