
#include <iostream>
#include <queue>
#include <stack>

#include "Grafo.h"

#define INT_MAX 2147483647

Grafo::Grafo() {

	this->idCapital = -1;
}

Grafo::~Grafo() {
	this->cidades.clear();
}

void Grafo::adCidade(Vertice nova) {
	this->cidades.push_back(nova);
}

Vertice* Grafo::achaCidadeID(int id) {
	
	for (int i = 0; i < this->cidades.size(); i++)
		if (this->cidades[i].pegaID() == id) 
			return &this->cidades[i];
}

Vertice* Grafo::achaCidadeString(std::string nome) {

	for (int i = 0; i < this->cidades.size(); i++)
		if (this->cidades[i].pegaNome() == nome)
			return &this->cidades[i];

	return nullptr;
}

int Grafo::pegaCapital() { return this->idCapital; }

void Grafo::defCapital() {

	int dist_min = INT_MAX; //menor distancia
	int cidadeID = 0; //id da cidade com menor distancia

	for (int i = 0; i < this->cidades.size(); i++) { //calcula as distancias entre as cidades para todas as cidades

		std::vector<int> percorridos(this->cidades.size(), 0);
		std::queue<Vertice> fila;
		this->cidades[i].reiniciaDists(this->cidades.size());
		this->calcDists(&this->cidades[i], this->cidades[i], percorridos, fila, 0);
	}

	for (int i = 0; i < this->cidades.size(); i++) { //verifica qual cidade tem menor custo, O(n)

		int distAtual = this->cidades[i].calcDistTotal(this->pegaPos(this->cidades[i].pegaID()));

		if (distAtual < dist_min && distAtual != -1) {
			dist_min = distAtual;
			cidadeID = this->cidades[i].pegaID();
		}

	}

	if (dist_min == INT_MAX) {
		std::cout << "Nao ha capital disponivel" << std::endl;
	}
	else {
		this->idCapital = cidadeID;
	}
}

void Grafo::calcDists(Vertice* origem, Vertice atual, std::vector<int> percorridos, std::queue<Vertice> fila, int distAtual) {

	if (!fila.empty()) fila.pop(); // se a fila nao estiver vazia, tira o primeiro item,ja que e ele que esta em escopo

	percorridos[this->pegaPos(atual.pegaID())] = 1; // define o vertice como visitado

	for (int i = 0; i < atual.grauVertice(); i++) { // Para cada cidade adjacente, calcula a nova distancia

		if ((origem->pegaDist(this->pegaPos(atual.pegaAresta(i))) > distAtual + 1 || origem->pegaDist(this->pegaPos(atual.pegaAresta(i))) == 0) && // Se a distancia for menor, ou a primeira
			atual.pegaAresta(i) != origem->pegaID()) // e nao for a origem
				origem->defDist(this->pegaPos(atual.pegaAresta(i)), distAtual + 1); // atualiza
		
		if (percorridos[this->pegaPos(atual.pegaAresta(i))] != 1) // se o vertice adjacente nao foi visitado
			fila.push(this->cidades[this->pegaPos(atual.pegaAresta(i))]); // adiciona o vertice adjacente na fila
	}
	if (!fila.empty()) { // se a fila nao estiver vazia
		this->calcDists(origem, fila.front(), percorridos, fila, origem->pegaDist(this->pegaPos(fila.front().pegaID()))); // chama o proximo da fila
	}
}

void Grafo::ordemExec(std::stack<int>& pilhaExec) {

	std::vector<int> percorridos(this->cidades.size(), 0);

	for (int i = 0; i < this->cidades.size(); i++) // para todo vertice
		if (percorridos[i] == 0) //caso ele nao tenha sido visitado
			this->percorre(pilhaExec, percorridos, &this->cidades[i]); // percorre todos os caminhos possiveis a partir dele
}

void Grafo::percorre(std::stack<int>& pilhaExec, std::vector<int>& percorridos, Vertice* atual) {

	percorridos[atual->pegaID()] = 1; // vertice percorrido

	for (int i = 0; i < atual->grauVertice(); i++) //para toda aresta deste vertice
		if (percorridos[atual->pegaAresta(i)] == 0) // se o vertice "destino" nao foi visitado ainda
			this->percorre(pilhaExec, percorridos, &this->cidades[atual->pegaAresta(i)]); // chama a mesma funcao, mas para o proximo vertice (como uma DFS)

	pilhaExec.push(atual->pegaID()); // adiciona o vertice na pilha de execucao
}

void Grafo::inverterGrafo() {

	std::vector<int> graus;

	for (int i = 0; i < this->cidades.size(); i++) {
		graus.push_back(this->cidades[i].grauVertice()); // armazena o grau dos vertices
	}

	for (int i = 0; i < this->cidades.size(); i++) { // para todo vertice

		Vertice* atual = &this->cidades[i];
		for (int j = 0; j < graus[i]; j++) { // para toda aresta original desse vertice

			Vertice* destino = &this->cidades[this->pegaPos(atual->pegaAresta(0))];
			destino->adCaminho(atual->pegaID());
			atual->tiraAresta(0); // remove a aresta antiga
		}
	}
}

void Grafo::agrupador(Vertice* atual, int numConjuntos) {

	for (int i = 0; i < atual->grauVertice(); i++){ // para cada aresta

		Vertice* destino = &this->cidades[atual->pegaAresta(i)];

		if (destino->pegaConjunto() == 0) { // verifica se o destino nao tem conjunto
			destino->defConjunto(numConjuntos);
			this->agrupador(destino, numConjuntos); //mesma funcao para o proximo vertice
		}
	}
}

bool Grafo::defBat(int numConjunto, std::vector<int>& idEmpatados) {// define batalhao do conjunto n

	int idBatalhao = -1;
	int distMin = INT_MAX;
	bool dualidade = false;

	Vertice capital = *this->achaCidadeID(this->idCapital);

	for (int i = 0; i < this->cidades.size(); i++) { // para os vertices do grafo
		if(this->cidades[i].pegaConjunto() == numConjunto) { // caso o vertice faça parte do conjunto
			if (capital.pegaDist(i) < distMin) { // verifica se a distancia dele para a capital e menor
				idBatalhao = i;
				distMin = capital.pegaDist(i);
				dualidade = false; // se as duas primeiras forem iguais, mas a terceira for menor, nao ha mais dualidade
				idEmpatados.clear();
			}
			else if (capital.pegaDist(i) == distMin) { // caso a distancia seja igual, temos 2 ou mais candidatos a batalhao
				dualidade = true;
				idEmpatados.push_back(idBatalhao);
				idEmpatados.push_back(i);
			}
		}
	}
	
	if (!dualidade) { // se nao houver dualidade, ja define o batalhao
		this->cidades[idBatalhao].defBatalhao();
	}
	return dualidade;
}

int Grafo::Kosaraju() {

	std::stack<int> pilhaExec;

	this->ordemExec(pilhaExec); // descobre o temppo de execucao de cada vertice e adiciona na pilha
	this->inverterGrafo(); //inverte o grafo

	int numConjuntos = 0;

	while (!pilhaExec.empty()) {

		Vertice* atual = &this->cidades[pilhaExec.top()];

		if (atual->pegaConjunto() == 0) { // coloca todos os vertices alcancaveis, a partir do atual, em um mesmo conjunto (fortemente conectados)
			numConjuntos++;
			atual->defConjunto(numConjuntos);
			this->agrupador(atual, numConjuntos);
		}

		pilhaExec.pop();
	}

	this->inverterGrafo(); // desinverte o grafo
	std::cout << numConjuntos - 1 << std::endl;
	return numConjuntos;
}

int Grafo::pegaPos(int id) {

	for (int i = 0; i < this->cidades.size(); i++)
		if (this->cidades[i].pegaID() == id)
			return i;
}

bool Grafo::eEuleriano(Grafo invertido) { //

	for (int i = 0; i < this->cidades.size(); i++)
		if (this->cidades[i].grauVertice() != invertido.cidades[i].grauVertice())
			return false;

	return true;
}

bool Grafo::equilibradoEnt(Grafo invertido, int pos) {

	return this->cidades[pos].grauVertice() < invertido.cidades[pos].grauVertice() ? false : true; // mais entrando q saindo
}

bool Grafo::equilibradoSai(Grafo invertido, int pos) {

	return this->cidades[pos].grauVertice() > invertido.cidades[pos].grauVertice() ? false : true; // mais saindo q entrando
}

void Grafo::euleriano() {

	Grafo invertido = *this;
	invertido.inverterGrafo(); // grafo invertido para medir balanceamento

	while (!this->eEuleriano(invertido)){ // enquanto o grafo nao for euleriano

		for (int i = 0; i < this->cidades.size(); i++) { // para todos os vertices
			if (!this->equilibradoEnt(invertido, i)) { // caso ele tenha poucas saidas
				Vertice* atual = &this->cidades[i];

				int modificado = 0;

				for (int j = 0; j < atual->grauVertice(); j++) { // para todos os vertices
					if (!this->equilibradoSai(invertido, this->pegaPos(atual->pegaAresta(j)))) { // da preferencia para os que nao estejam equilibrados na saida
						atual->adCaminho(atual->pegaAresta(j));
						invertido.cidades[this->pegaPos(atual->pegaAresta(j))].adCaminho(atual->pegaID());
						modificado = 1;
					}
				}

				if (modificado == 0) {
					for (int j = 0; j < atual->grauVertice(); j++) { // para todos os vertices
						if (this->equilibradoEnt(invertido, this->pegaPos(atual->pegaAresta(j)))) { // da preferencia para os que estejam equilibrados
							atual->adCaminho(atual->pegaAresta(j));
							invertido.cidades[this->pegaPos(atual->pegaAresta(j))].adCaminho(atual->pegaID());
							modificado = 1;
						}
					}
				}

				if (modificado == 0) { //ultimo caso
					atual->adCaminho(atual->pegaAresta(0));
					invertido.cidades[this->pegaPos(atual->pegaAresta(0))].adCaminho(atual->pegaID());
				}
			}
		}
	}
}

void Grafo::patrulhamento(int numConjuntos) {

	int conjuntosPercorridos = 1, contCaminhos_pos = 0;
	std::vector<std::stack<std::string>> listaCaminhos;

	while (conjuntosPercorridos <= numConjuntos){ // enquanto nao tenha patrulha para todos os conjuntos

		Grafo grafoAux;
		int idBatalhao = 0;
		bool conjuntoCapital = false, dualidade = false;

		for (int i = 0; i < this->cidades.size(); i++) {
			if (this->cidades[i].pegaConjunto() == conjuntosPercorridos) { // pega os vertices do conjunto

				if (this->cidades[i].pegaID() == this->idCapital) { //marca posicao de inicio do Hierholzer, se for capital
					conjuntoCapital = true;
					idBatalhao = this->cidades[i].pegaID();
				}

				Vertice* original = &this->cidades[i];
				Vertice aux(original->pegaID(), original->pegaNome(), 0, original->pegaConjunto(), original->eBatalhao()); // cria uma copia quase igual

				for (int j = 0; j < original->grauVertice(); j++) { //para todos as arestas do vertice original
					if (this->cidades[original->pegaAresta(j)].pegaConjunto() == aux.pegaConjunto()) { //se o vertice destino for do mesmo conjunto que o vertice atual
						aux.adCaminho(original->pegaAresta(j)); // adiciona a aresta no vertice copiado
					}
				}
				grafoAux.adCidade(aux); // adiciona o novo vertice ao novo grafo
			}
		}

		if (!conjuntoCapital) { // se o conjunto nao tem capital, define onde fica o batalhao dele

			std::vector<int> idEmpatados;

			dualidade = this->defBat(conjuntosPercorridos, idEmpatados); // verifica qual batalhao esta mais proximo da capital e se a mais de uma cidade com a mesma distancia

			if (!dualidade) { // se nao houver dualidade
				for (int i = 0; i < this->cidades.size(); i++) {
					if (this->cidades[i].pegaConjunto() == conjuntosPercorridos && this->cidades[i].eBatalhao()) { // acha o vertice batalhao do conjunto
						idBatalhao = i; // define ele como o ponto de comeco
					}
				}
				std::cout << this->achaCidadeID(idBatalhao)->pegaNome() << std::endl;
			}
			else { //mais de um batalhao com a mesma distancia para a capital
				grafoAux.defCapital(); // acha a "capital" do subconjunto
				int distMin = INT_MAX;
				int idBat = -1;
				for (int i = 0; i < idEmpatados.size(); i++) {
					int dist = grafoAux.cidades[grafoAux.pegaPos(idEmpatados[i])].calcDistTotal(grafoAux.pegaPos(idEmpatados[i]));
					if (dist < distMin) {
						idBat = idEmpatados[i];
						distMin = dist;
					}
				}
				idBatalhao = idBat; // define ele como o ponto de comeco
				std::cout << grafoAux.cidades[grafoAux.pegaPos(idBat)].pegaNome() << std::endl;
			}
		}

		std::stack<std::string> caminho;

		grafoAux.euleriano(); // transforma o grafo em euleriano
		grafoAux.Hierholzer(caminho, grafoAux.achaCidadeID(idBatalhao)); // acha o menor caminho

		if (caminho.size() > 1) {
			contCaminhos_pos++;
		}

		listaCaminhos.push_back(caminho);

		conjuntosPercorridos++;
	}

	std::cout << contCaminhos_pos << std::endl;

	for (int i = 0; i < listaCaminhos.size(); i++) { // para todos os caminhos
		if (listaCaminhos[i].size() > 1) { // se ele for maior que 1
			while (listaCaminhos[i].size() > 1) { // imprime todos os vertices do caminho
				std::cout << listaCaminhos[i].top() << " ";
				listaCaminhos[i].pop();
			}
			std::cout << std::endl;
		}
	}
}

void Grafo::Hierholzer(stack<string>& caminho, Vertice* atual) {

	//std::cout << "Nome vertice atual: " << atual->pegaNome() << std::endl;

	for (int i = 0; i < atual->grauVertice(); i++) {
		//std::cout << "Nome vertice destino " << this->achaCidadeID(atual->pegaAresta(i))->pegaNome() << std::endl;
		if (!atual->verfPercorrido(i)) {
			//std::cout << "Nao percorrido" << std::endl;
			atual->defPercorrido(i);
			this->Hierholzer(caminho, this->achaCidadeID(atual->pegaAresta(i)));
		}
	}
	//std::cout << "nome entrando na pilha " << atual->pegaNome() << std::endl;
	caminho.push(atual->pegaNome());
}